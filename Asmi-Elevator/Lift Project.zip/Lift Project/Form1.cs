﻿using LiftDemo_A;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lift_Project
{
    public partial class Form1 : Form
    {
        bool isClosing = false;
        bool isOpening = false;

        int doorMaxOpenWidth;
        int doorSpeed = 5;
        int liftSpeed = 5;
        //bool isMovingUp = false;
        //bool isMovingDown = false;

        private Lift lift;
        //string connectionstring = @"server=DESKTOP-CRK0I9F\ASMI; Database= Asmi;Trusted_connection=True";
        DataTable dt=new DataTable();
        Db_context db_Context = new Db_context();

        public Form1()
        {
            InitializeComponent();

            lift = new Lift(mainElevator, btn_1, btn_G, this.ClientSize.Height, liftSpeed, liftTimerUp, liftTimerDown, fFloorBack);


            doorMaxOpenWidth = mainElevator.Width / 2;

            dataGridView.ColumnCount= 2;
            dataGridView.Columns[0].Name = "Time";
            dataGridView.Columns[1].Name = "Events";

            dt.Columns.Add("Time");
            dt.Columns.Add("Events");
        }
        private void logEvents(string message)
        {
            string currentTime = DateTime.Now.ToString("hh:mm:ss");

            dt.Rows.Add(currentTime, message);
            dataGridView.Rows.Add(currentTime,message);

            db_Context.InsertLogsIntoDB(dt); 

        }
        

        private void Form1_Load(object sender, EventArgs e)
        {
            db_Context.LoadLogsfromDB(dt, dataGridView);
        }

        private void btn_1_Click(object sender, EventArgs e)
        {
            lift.SetState(new MovingUpState());
            lift.LiftTimerUp.Start();
            logEvents("lift first floor");

        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            lift.SetState(new MovingDownState());
            lift.LiftTimerDown.Start();
            logEvents("lift ground floor");

        }

        public void liftTimerUp_Tick(object sender, EventArgs e)
        {
            lift.MovingUp();
        }

        public void liftTimerDown_Tick(object sender, EventArgs e)
        {
            lift.MovingDown();
        }

        private void btn_open_Click(object sender, EventArgs e)
        {
         isOpening = true;
         isClosing = false;
         doorTimer.Start();
         btn_Close.Enabled = false;
         logEvents("Lift open");
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            isOpening = false;
            isClosing = true;
            doorTimer.Start();
            logEvents("Lift closed");
        }

        private void door_Timer_Tick(object sender, EventArgs e)

		{
			if (mainElevator.Top != 0)
			{
				if (isOpening)
				{
					if (doorLeft_G.Left > doorMaxOpenWidth / 2+65)
					{
                        doorLeft_G.Left -= doorSpeed;
						doorRight_G.Left += doorSpeed;
					}
					else
					{
						doorTimer.Stop();
						btn_Close.Enabled = true;
					}
				}

				if (isClosing)
				{
					if (doorLeft_G.Right < mainElevator.Width + doorMaxOpenWidth / 2 +65)
					{
                        doorLeft_G.Left += doorSpeed;
						doorRight_G.Left -= doorSpeed;
					}
					else
					{
						doorTimer.Stop();

					}
				}
			}

			else
			{
				if (isOpening)
				{
					if (doorLeft_1.Left > doorMaxOpenWidth / 2+50)
					{
                        doorLeft_1.Left -= doorSpeed;
						doorRight_1.Left += doorSpeed;
					}
					else
					{
						doorTimer.Stop();
						btn_Close.Enabled = true;
					}
				}

				if (isClosing)
				{
					if (doorLeft_1.Right < mainElevator.Width + doorMaxOpenWidth / 2+35)
					{
                        doorLeft_1.Left += doorSpeed;
						doorRight_1.Left -= doorSpeed;
					}
					else
					{
						doorTimer.Stop();

					}
				}
			}
		}

        private void btn_Delete_Click(object sender, EventArgs e)
        {
         db_Context.DeleteAllLogs(dt, dataGridView);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void doorLeft_G_Click(object sender, EventArgs e)
        {

        }

        private void mainElevator_Click(object sender, EventArgs e)
        {

        }

        private void doorLeft_1_Click(object sender, EventArgs e)
        {

        }

        private void groundFloor_Click(object sender, EventArgs e)
        {

        }
    }
}
